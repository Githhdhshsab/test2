export function isEmptyObject(obj: Object) {
    return Object.keys(obj).length === 0
}

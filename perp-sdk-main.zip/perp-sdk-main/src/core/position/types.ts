export enum PositionSide {
    LONG = "LONG",
    SHORT = "SHORT",
}

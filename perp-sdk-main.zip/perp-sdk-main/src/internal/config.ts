export interface ModuleConfig {
    period: number
}

export const DEFAULT_PERIOD = 5000

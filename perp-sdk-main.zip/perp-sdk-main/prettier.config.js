module.exports = {
    semi: false,
    printWidth: 120,
    singleQuote: false,
    trailingComma: "all",
    arrowParens: "avoid",
    tabWidth: 4,
    bracketSpacing: true,
}
